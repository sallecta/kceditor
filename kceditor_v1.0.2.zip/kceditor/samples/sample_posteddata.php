<?php /* <body><pre>

-------------------------------------------------------------------------------------------
   KCEditor - Posted Data

  We are sorry, but your Web server does not support the PHP language used in this script.

  Please note that  KCEditor can be used with any other server-side language than just PHP.
  To save the content created with  KCEditor you need to read the POST data on the server
  side and write it to a file or the database.

  Copyright (c) 2003-2023, CKSource.
  For licensing, see LICENSE or https://github.com/sallecta/kceditor/blob/main/LICENSE
-------------------------------------------------------------------------------------------

</pre><div style="display:none"></body> */ include "assets/posteddata.php"; ?>
