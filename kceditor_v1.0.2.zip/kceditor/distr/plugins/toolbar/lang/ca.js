﻿/*
Copyright (c) 2003-2023, KCEditor . All rights reserved.
For licensing, see LICENSE.md or https://github.com/sallecta/kceditor/blob/main/LICENSE.md
*/
kceditor.plugins.setLang( 'toolbar', 'ca', {
	toolbarCollapse: 'Redueix la barra d\'eines',
	toolbarExpand: 'Amplia la barra d\'eines',
	toolbarGroups: {
		document: 'Document',
		clipboard: 'Clipboard/Undo',
		editing: 'Editing',
		forms: 'Forms',
		basicstyles: 'Basic Styles',
		paragraph: 'Paragraph',
		links: 'Links',
		insert: 'Insert',
		styles: 'Styles',
		colors: 'Colors',
		tools: 'Tools'
	},
	toolbars: 'Editor de barra d\'eines'
} );
