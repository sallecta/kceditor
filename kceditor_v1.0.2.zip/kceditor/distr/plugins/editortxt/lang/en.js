﻿kceditor.plugins.setLang( 'editortxt', 'en', {
	typeHere: 'Type here...'
} );
