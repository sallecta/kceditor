﻿kceditor.plugins.setLang( 'about', 'en', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'About KCEditor',
	moreInfo: 'Licensed under the terms of any of the following licenses: '+
	'<ul>'+
	'<li>GPL (https://www.gnu.org/licenses/gpl.html),'+
	'<li>LGPL (https://www.gnu.org/licenses/lgpl.html),'+
	'<li>MPL (https://www.mozilla.org/MPL/MPL-1.1.html)'+
	'</ul>'
} );
