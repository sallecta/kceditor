﻿/*
Copyright (c) 2003-2023, KCEditor . All rights reserved.
For licensing, see LICENSE.md or https://github.com/sallecta/kceditor/blob/main/LICENSE.md
*/
kceditor.plugins.setLang( 'undo', 'gu', {
	redo: 'રિડૂ; પછી હતી એવી સ્થિતિ પાછી લાવવી',
	undo: 'રદ કરવું; પહેલાં હતી એવી સ્થિતિ પાછી લાવવી'
} );
