﻿/*
Copyright (c) 2003-2023, KCEditor . All rights reserved.
For licensing, see LICENSE.md or https://github.com/sallecta/kceditor/blob/main/LICENSE.md
*/
kceditor.plugins.setLang( 'undo', 'zh', {
	redo: '取消復原',
	undo: '復原'
} );
