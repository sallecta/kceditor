﻿/*
Copyright (c) 2003-2023, KCEditor . All rights reserved.
For licensing, see LICENSE.md or https://github.com/sallecta/kceditor/blob/main/LICENSE.md
*/
kceditor.plugins.setLang( 'undo', 'af', {
	redo: 'Oordoen',
	undo: 'Ontdoen'
} );
