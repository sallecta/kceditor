﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
kceditor.skin.name="office2013";kceditor.skin.ua_editor="";kceditor.skin.ua_dialog="";kceditor.skin.chameleon=function(){return""};
