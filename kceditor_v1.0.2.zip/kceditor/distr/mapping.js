kceditor.domReady = kceditor.events.dom_ready
